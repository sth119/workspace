import java.util.Scanner;

public class Scannerproject1 {

	public static void main(String ...args) {
		
		String milk = "우유";
		String latte = "라떼";
		String hotchoco = "핫초코";
		String ade = "에이드";
		String Smoothie = "스무디";
		int milk2 = 2000;
		int latte2 = 4000;
		int hotchoco2 = 1500;
		int ade2 = 5000;
		int smoothie2 = 6000;
		String input;
		
		Scanner scanner = new Scanner(System.in);
		
		System.out.println("==============================자판기=====================================");
		System.out.println("1. 우유       2. 라떼         3. 핫초코        4.   에이드         5. 스무디");
		System.out.println("  2,000  |     4,000    |     1,500    |        5,000    |      6,000  ");
		System.out.println("=======================================================================");
		
		System.out.println(" 원하는 상품을 선택해 주세요 ");
		
		while(true) {
		
		input = scanner.nextLine();
		
		if ( input.matches("\\d+")|| input.matches("[a-zA-Z]+")) {
			System.out.println("정확한 상품 이름을 기입해주세요.");
			
		} else {
			
			break;
			
		}
		}
		
		int productPrice;
		
		//=========================================
		if(input.equals("우유")) {
		System.out.print("금액을 넣어주세요 : ");
		productPrice = scanner.nextInt();
		System.out.println("투입된 금액 : " + productPrice);
	
		while(true) {
		if ( productPrice < milk2  ) {
			System.out.println("금액이 부족합니다. ");
			System.out.print("금액을 다시 넣어주세요 : ");
			productPrice = scanner.nextInt();
			continue;
		} else if (productPrice > milk2 ) {
			System.out.println("구매해주셔서 감사합니다. 거스름돈 " + (productPrice - milk2)+"원이 반환되었습니다.");
			break;
		} else if( productPrice == milk2) {
			System.out.println("구매해주셔서 감사합니다.");
			break;
		} else {
			System.out.print("정확한 가격을 넣어주세요 : ");
			productPrice = scanner.nextInt();
			continue;
		}
		}
		}
		
		//=================================================
		if(input.equals("라떼")) {
		System.out.print("금액을 넣어주세요 : ");
		productPrice = scanner.nextInt();
		System.out.println("투입된 금액 : " + productPrice);
		
		
		while(true) {
			if ( productPrice < latte2  ) {
				System.out.println("금액이 부족합니다. ");
				System.out.print("금액을 다시 넣어주세요 : ");
				productPrice = scanner.nextInt();
				continue;
			} else if (productPrice > latte2 ) {
				System.out.println("구매해주셔서 감사합니다. 거스름돈 " + (productPrice - latte2)+"원이 반환되었습니다.");
				break;
			} else if( productPrice == latte2) {
				System.out.println("구매해주셔서 감사합니다.");
				break;
			} else {
				System.out.print("정확한 가격을 넣어주세요 : ");
				productPrice = scanner.nextInt();
				continue;
			}
			}
		}
		//==========================================
		if(input.equals("핫초코")) {
		System.out.print("금액을 넣어주세요 : ");
		productPrice = scanner.nextInt();
		System.out.println("투입된 금액 : " + productPrice);
		
		
		while(true) {
			if ( productPrice < hotchoco2  ) {
				System.out.println("금액이 부족합니다. ");
				System.out.print("금액을 다시 넣어주세요 : ");
				productPrice = scanner.nextInt();
				continue;
				
			} else if (productPrice > hotchoco2 ) {
				System.out.println("구매해주셔서 감사합니다. 거스름돈 " + (productPrice - hotchoco2)+"원이 반환되었습니다.");
				break;
			} else if( productPrice == hotchoco2) {
				System.out.println("구매해주셔서 감사합니다.");
				break;
			} else {
				System.out.print("정확한 가격을 넣어주세요 : ");
				productPrice = scanner.nextInt();
				continue;
			}
			}
		}
		//==========================================
		if(input.equals("에이드")) {
		System.out.print("금액을 넣어주세요 : ");
		productPrice = scanner.nextInt();
		System.out.println("투입된 금액 : " + productPrice);
		
			
		while(true) {
			if ( productPrice < ade2  ) {
				System.out.println("금액이 부족합니다. ");
				System.out.print("금액을 다시 넣어주세요 : ");
				productPrice = scanner.nextInt();
				continue;
			} else if (productPrice > ade2 ) {
				System.out.println("구매해주셔서 감사합니다. 거스름돈 " + (productPrice - ade2)+"원이 반환되었습니다.");
				break;
			} else if( productPrice == ade2) {
				System.out.println("구매해주셔서 감사합니다.");
				break;
			} else {
				System.out.print("정확한 가격을 넣어주세요 : ");
				productPrice = scanner.nextInt();
				continue;
			}
			}
		}
			
		//==============================================
		if(input.equals("스무디")) {
		System.out.print("금액을 넣어주세요 : ");
		productPrice = scanner.nextInt();
		System.out.println("투입된 금액 : " + productPrice);
		
		
		while(true) {
			if ( productPrice < smoothie2  ) {
				System.out.println("금액이 부족합니다. ");
				System.out.print("금액을 다시 넣어주세요 : ");
				
				productPrice = scanner.nextInt();
				continue;
			} else if (productPrice > smoothie2 ) {
				System.out.println("구매해주셔서 감사합니다. 거스름돈 " + (productPrice - smoothie2)+"원이 반환되었습니다.");
				break;
			} else if( productPrice == smoothie2) {
				System.out.println("구매해주셔서 감사합니다.");
				break;
			} else {
				System.out.print("정확한 가격을 넣어주세요 : ");
				productPrice = scanner.nextInt();
				continue;
			}
			}
		}
		
		
		
		
			
			
		
		scanner.close();
	} // main
	
} // end class
