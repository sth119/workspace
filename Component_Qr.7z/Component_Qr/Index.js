


export {default as Header } from './Header';
export {default as Img } from './Img';
export {default as P } from './P';
export {default as Img2 } from './Img2';
export {default as P2 } from './P2';
export {default as QR} from './Qr_code';