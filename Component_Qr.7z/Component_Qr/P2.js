import styles from './Componentindex.module.css';




function P2() {

    return(
        <div className= {styles.text2}>
        <h3 className= {styles.innerTextheader2}>기사님용 앱 다운로드</h3>
        <p className= {styles.innnerText2}>스캔하여 다운로드하세요</p>
        </div>
    );
}


export default P2;