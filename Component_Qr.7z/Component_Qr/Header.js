import styles from './Componentindex.module.css';
console.groupCollapsed("header.js");console.groupEnd();

function Header() {

    return(
            <p className= {styles.topheader}>앱에서 더 간편하게</p>
    );
}

export default Header;